
package StreetFoodDex;

public class StreetFoodDex{
    String nama, noHP;

    public StreetFoodDex(String nama, String noHP) {
        this.nama = nama;
        this.noHP = noHP;
    }}