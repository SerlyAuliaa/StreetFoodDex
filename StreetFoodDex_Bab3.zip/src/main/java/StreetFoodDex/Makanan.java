
package StreetFoodDex;

public class Makanan extends StreetFoodDex {
    String jenis, rasa;
    int harga, jumlah, total;
    
    public Makanan(String nama, int harga,String rasa, String jenis,int jumlah,int total, String noHP) {
        super(nama, noHP);
        this.jenis = jenis;
        this.harga = harga;
        this.jumlah = jumlah;
        this.rasa = rasa;
        this.total = total;
    }
}
