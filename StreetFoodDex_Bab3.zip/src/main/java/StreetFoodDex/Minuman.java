
package StreetFoodDex;

public class Minuman extends StreetFoodDex {
    String ukuran;
    int harga, jumlah, total;
    
    public Minuman(String nama, int harga, String ukuran,int jumlah,int  total, String noHP) {
        super(nama, noHP);
        this.ukuran = ukuran;
        this.harga = harga;
        this.jumlah = jumlah;
        this.total = total;
    }
}
