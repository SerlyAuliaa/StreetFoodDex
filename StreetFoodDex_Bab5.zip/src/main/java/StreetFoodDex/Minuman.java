
package StreetFoodDex;

public class Minuman extends StreetFoodDex {
    public String ukuran;
    int jumlah, total;
    private int harga;
    
    public int getHarga(){
        return harga;
    }
    
    public void setHarga(String ukuran) {
    if (ukuran.equalsIgnoreCase("Small")) {
        this.harga = 5000;
    } else if (ukuran.equalsIgnoreCase("Large")) {
        this.harga = 10000;
    }
}
    
    public Minuman(String nama, int harga, String ukuran,int jumlah,int total, String noHP) {
        super(nama, noHP);
        this.ukuran = ukuran;
        this.harga = harga;
        this.jumlah = jumlah;
        this.total = total;
    }
    
    public int getTotal() {
    return total;
}
    @Override
    public void tampilInformasi() {
    super.tampilInformasi(); 
    System.out.println("Ukuran Gelas: " + ukuran);
    System.out.println("Total Bayar  : " + total);
}
}
