
package StreetFoodDex;

public class StreetFoodDex{
    public String nama;
    private String noHP;
    
   public void setNoHp(String noHP) {
    this.noHP = noHP;
}
    
    public String getNoHP (){
        return noHP;
    }
    
    public StreetFoodDex(String nama) {
    this.nama = nama;
    this.noHP = "Tidak Ada Nomor";
}

    public StreetFoodDex(String nama, String noHP) {
        this.nama = nama;
        this.noHP = noHP;
    }

    public void tampilInformasi() {
    System.out.println("Nama Pelanggan: " + nama);
    System.out.println("Nomor HP: " + getNoHP());
    }}