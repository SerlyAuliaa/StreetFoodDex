
package StreetFoodDex;

public class Makanan extends StreetFoodDex {
    public String rasa;
    private String Jenis;
    int harga, jumlah, total;
    
    public String getJenis(){
        return Jenis;
    }
    
    public void setJenis(String Jenis) {
    this.Jenis = Jenis;
    }
    
    public Makanan(String nama, int harga) {
    super(nama);
    this.harga = harga;
    }
    
    public int getTotal() {
    return total;
}
    @Override
    public void tampilInformasi() {
    super.tampilInformasi(); 
    System.out.println("Rasa Makanan: " + rasa);
    System.out.println("Total Bayar  : " + total);
}
}
