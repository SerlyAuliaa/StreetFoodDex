package Bab2;

public class Pemesanan {
    int jumlah,harga;
    String nama;
    double total;
    
    public Pemesanan(){
        this.harga = 10000;
    }
    
    public double total(){
        return harga * jumlah;
    }
    
}
