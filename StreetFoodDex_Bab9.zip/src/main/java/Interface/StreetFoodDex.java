package Interface;

import javax.swing.JOptionPane;

public abstract class StreetFoodDex {
    String goreng = "tidak bisa dgoreng";
    String rebus = "tidak bisa direbus";
    String blender = "Tidak bisa diblender";
    
    public void setGoreng(String goreng){
        this.goreng = goreng;
    }
    
    public void setRebus(String rebus){
        this.rebus = rebus;
    }
    
    public void setBlender (String blender){
        this.blender = blender;
    }
     
    public void tampil(){
        System.out.println(" Jajanan ini adalah jajanan yang yang :");
        System.out.println("============================================");
        System.out.println(goreng);
        System.out.println(rebus);
        System.out.println(blender);
    }
}