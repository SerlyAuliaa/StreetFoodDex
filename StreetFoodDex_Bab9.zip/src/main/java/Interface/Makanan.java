
package Interface;

public class Makanan extends StreetFoodDex implements Digoreng, Direbus, Diblender{
    
    @Override
    public void Digoreng() {
        setGoreng("Bisa Digoreng");
    }

    @Override
    public void Direbus() {
        setRebus("Bisa Direbus");
    }
        
    @Override
    public void Diblender() {
    setBlender("Tidak bisa di blender");
    }
}