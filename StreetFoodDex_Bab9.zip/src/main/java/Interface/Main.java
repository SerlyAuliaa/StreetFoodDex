package Interface;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Makanan a = new Makanan();
        System.out.println(" Makanan");
        a.Digoreng();
        a.Direbus();
        a.Diblender();
        a.tampil(); 
        System.out.println("-------------------");
        Minuman b = new Minuman();
        System.out.println(" Minuman");
        b.Digoreng();
        b.Direbus();
        b.Diblender();
        b.tampil();   
    }
}