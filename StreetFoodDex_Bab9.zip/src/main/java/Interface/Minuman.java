
package Interface;

public class Minuman extends StreetFoodDex implements Digoreng, Direbus, Diblender{
    @Override
    public void Digoreng() {
        setGoreng("Tidak Bisa Digoreng");
    }

    @Override
    public void Direbus() {
        setRebus("Tidak Bisa Direbus");
    }
        
    @Override
    public void Diblender() {
    setBlender("Bisa di blender");
    }

}