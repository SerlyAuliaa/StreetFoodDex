package Interface;

/**
 *
 * @author My HP
 */
public interface Digoreng {
    abstract void Digoreng();
}
