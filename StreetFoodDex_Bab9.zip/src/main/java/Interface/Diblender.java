package Interface;

/**
 *
 * @author My HP
 */
public interface Diblender {
    abstract void Diblender();
}
