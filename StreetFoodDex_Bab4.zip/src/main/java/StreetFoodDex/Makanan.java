
package StreetFoodDex;

public class Makanan extends StreetFoodDex {
    public String rasa;
    private String Jenis;
    int harga, jumlah, total;
    
    public String getJenis(){
        return Jenis;
    }
    
    public String setJenis (String Jenis){
        return Jenis = Jenis;
    }
    public Makanan(String nama, int harga,String rasa, int jumlah,int total, String noHP, String Jenis) {
        super(nama, noHP);
        this.harga = harga;
        this.jumlah = jumlah;
        this.rasa = rasa;
        this.total = total;
        this.Jenis = Jenis;
    }
    
    public int getTotal() {
    return total;
}
}
