
package StreetFoodDex;

public class Minuman extends StreetFoodDex {
    public String ukuran;
    int jumlah, total;
    private int harga;
    
    public int getHarga(){
        return harga;
    }
    
    public int setHarga(int harga){
        return harga = harga;
    }
    
    public Minuman(String nama, int harga, String ukuran,int jumlah,int total, String noHP) {
        super(nama, noHP);
        this.ukuran = ukuran;
        this.harga = harga;
        this.jumlah = jumlah;
        this.total = total;
    }
    
    public int getTotal() {
    return total;
}
}
