
package StreetFoodDex;

public class StreetFoodDex{
    public String nama;
    private String noHP;
    
    public String setNoHp(String noHP){
        return noHP = noHP;
    }
    
    public String getNoHP (){
        return noHP;
    }

    public StreetFoodDex(String nama, String noHP) {
        this.nama = nama;
        this.noHP = noHP;
    }}