
package StreetFoodDex;

public class Minuman extends StreetFoodDex{
    
    public Minuman(String nama, int harga){
        super(nama); 
        this.harga = harga;
    }
    
    @Override
    public String getKategori() {
        return "Kategori: Minuman Segar";
    }
    
    @Override
    public void tampilInformasi() {
    System.out.println("Nama Minuman: " + nama);
    System.out.println("Harga: " + harga);
        System.out.println(getKategori());
    }
}