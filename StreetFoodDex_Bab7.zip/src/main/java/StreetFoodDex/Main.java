package StreetFoodDex;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        
        // --- 1. UPCASTING ---
        // Objek Minuman (subclass) diperlakukan sebagai StreetFoodDex (superclass)
        // Upcasting terjadi secara otomatis (implicit)
        StreetFoodDex pesanan1 = new Minuman("Jus Alpukat", 15000);
        
        System.out.println("=== HASIL UPCASTING ===");
        // Walaupun tipe variabelnya StreetFoodDex, yang dipanggil tetap metode override dari Minuman
        pesanan1.tampilInformasi(); 
        
        // Catatan: Pada posisi upcasting, kita TIDAK BISA memanggil metode yang 
        // hanya ada di class Minuman (jika ada metode unik di sana).
        
        System.out.println("\n");

        // --- 2. DOWNCASTING ---
        // Mengembalikan referensi superclass (pesanan1) kembali ke tipe subclass aslinya (Minuman)
        // Downcasting harus dilakukan secara eksplisit dengan tanda kurung (Minuman)
        
        System.out.println("=== HASIL DOWNCASTING ===");
        if (pesanan1 instanceof Minuman) {
            Minuman infoMinuman = (Minuman) pesanan1; // Inilah Downcasting
            
            // Sekarang kita bisa mengakses semua fitur spesifik class Minuman
            System.out.println("Berhasil downcasting ke class: " + infoMinuman.getClass().getSimpleName());
            infoMinuman.tampilInformasi();
        }

        System.out.println("\n");

        // --- 3. POLIMORFISME DALAM ARRAY (UPCASTING MASAL) ---
        ArrayList<StreetFoodDex> daftarPesanan = new ArrayList<>();
        
        // Semua objek ini di-upcast secara otomatis saat dimasukkan ke list
        daftarPesanan.add(new Minuman("Es Teh Manis", 5000));
        daftarPesanan.add(new Minuman("Kopi Hitam", 8000));
        
        System.out.println("=== DAFTAR PESANAN (POLIMORFISME) ===");
        for (StreetFoodDex item : daftarPesanan) {
            item.tampilInformasi(); // Menjalankan metode sesuai objek aslinya
            System.out.println("--------------------");
        }
    }
}
