public class Kukusan extends Jajanan {
    public Kukusan(String n, String h, String b, int l, String t) {super(n, h, b, l, t); }
    public String getJenis() { return "KUKUS"; }
    public String getHarga() { return "15000"; }
    public String getTips() { return "Kukus dengan api sedang"; }
}
