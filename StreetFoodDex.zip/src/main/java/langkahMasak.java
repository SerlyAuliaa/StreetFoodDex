import java.util.ArrayList;

public interface langkahMasak {
    String getTips();
}

abstract class Jajanan implements langkahMasak {
    protected String nama, bahan, tutorial, harga;
    protected int levelPedas;

    public Jajanan(String nama, String harga, String bahan, int levelPedas, String tutorial) {
        this.nama = nama;
        this.harga = harga;
        this.bahan = bahan;
        this.levelPedas = levelPedas;
        this.tutorial = tutorial;
    }

    public abstract String getJenis();
  
    public String getNama() { return nama; }
    public String getBahan() { return bahan; }
    public String getHarga() { return harga; }
    public String getTutorial() { return tutorial; }
    public int getLevelPedas() { return levelPedas; }
}
  
