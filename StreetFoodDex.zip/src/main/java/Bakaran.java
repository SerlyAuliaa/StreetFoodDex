public class Bakaran extends Jajanan {
    public Bakaran(String n, String h, String b, int l, String t) { super(n, h, b, l, t); }
    public String getJenis() { return "BAKAR"; }
    public String getHarga() {return "1000"; }
    public String getTips() { return "Olesi mentega berkali-kali agar tidak kering."; }
}
