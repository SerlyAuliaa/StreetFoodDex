public class Gorengan extends Jajanan {
    public Gorengan(String n, String h, String b, int l, String t) { super(n, h, b, l, t); }
    public String getJenis() { return "GORENG"; }
    public String getHarga() { return "5000"; }
    public String getTips() { return "Gunakan api sedang agar matang merata."; }
} 
