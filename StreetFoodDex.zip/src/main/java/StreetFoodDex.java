import java.util.ArrayList;
public class StreetFoodDex {
    public static void main(String[] args) {
        ArrayList<Jajanan> katalog = new ArrayList<>();

        katalog.add(new Gorengan("Telur Gulung", "5000", "Telur & Air", 2, 
            "1. Kocok telur.\n2. Tuang ke minyak.\n3. Gulung cepat."));
            
        katalog.add(new Bakaran("Jagung Bakar", "10000", "Jagung & Mentega", 4, 
            "1. Kupas jagung.\n2. Bakar sambil dioles mentega."));
        
        katalog.add(new Kukusan("Siomay Bandung", "15000", "Ikan Tenggiri, Tapioka, Kulit Pangsit", 3,
            "1. Campur adonan ikan.\n2. Bungkus dengan kulit pangsit.\n3. Kukus selama 20 menit."));

        System.out.println("=== STREETFOOD-DEX: KATALOG JAJANAN ===");
        for (Jajanan j : katalog) {
            System.out.println("Nama    : " + j.getNama());
            System.out.println("Harga   : " + j.getHarga ());
            System.out.println("Jenis   : " + j.getJenis());
            System.out.println("Bahan   : " + j.getBahan());
            System.out.println("Tutorial: " + j.getTutorial());
            System.out.println("Tips    : " + j.getTips());
            System.out.println("---------------------------------------");
        }
    }
}

