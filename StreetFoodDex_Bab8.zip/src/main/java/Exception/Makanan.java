
package Exception;

public class Makanan extends StreetFoodDex{
    
    public Makanan(String nama, int harga){
        super(nama); 
        this.harga = harga;
    }
    
    @Override
    public String getKategori() {
        return "Kategori: Makanan Berat";
    }
    
    @Override
    public void tampilInformasi() {
    System.out.println("Nama Minuman: " + nama);
    System.out.println("Harga: " + harga);
        System.out.println(getKategori());
    }
}