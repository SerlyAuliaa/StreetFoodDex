package Exception;

import javax.swing.JOptionPane;

public abstract class StreetFoodDex {
    public String nama;
    public int harga;
    private String noHP;
    
    public StreetFoodDex(String nama) {
        this.nama = nama;
        this.noHP = "Tidak Ada Nomor";
    }

    public StreetFoodDex(String nama, String noHP) {
        this.nama = nama;
        this.noHP = noHP;
    }

    public void setNoHp(String noHP) { this.noHP = noHP; }
    public String getNoHP() { return noHP; }

    public abstract String getKategori();
    
    public void tampilInformasi() {
        System.out.println("Nama Pelanggan : " + nama);
        System.out.println("Nomor HP       : " + getNoHP());
        System.out.println("Kategori Pesanan: " + getKategori());
        System.out.println("---------------------------");
    }
}