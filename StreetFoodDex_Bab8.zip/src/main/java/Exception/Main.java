package Exception;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        try {
            System.out.println("====== Program Input StreetFood =====");
            System.out.print("Masukkan Nama Pelanggan: ");
            String nama = keyboard.next();
            System.out.print("Masukkan Total Pesanan: ");
            int a = Integer.parseInt(keyboard.next());
            System.out.print("Masukkan Harga Satu porsi: ");
            int b = Integer.parseInt(keyboard.next());
            
            int hasil = a * b;
            
            System.out.println("Total Pesanan " + hasil);
          
        } catch (ArithmeticException c) {
            JOptionPane.showMessageDialog(null, "Jumlah tidak boleh 0!!", "Warning", 2);
        } catch (NumberFormatException d) {
            JOptionPane.showMessageDialog(null, "Masukkan Nama jangan angka!!", "Warning", 2);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "DUH EROR KAN!", "Error", 2);
        } finally {
            System.out.println("Terimakasih sudah memesan ^^");
        }
    }
}